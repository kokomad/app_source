package com.khader.launcher

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

/**
 * لانشر خضر 3D - Khader Launcher 3D
 * Developer: خضر أبو صالحه  <mankhader@gmail.com>
 */
class VH(val cell: LinearLayout, val tile: Tile3D, val tv: TextView) : RecyclerView.ViewHolder(cell)

class PageVH(val frame: FrameLayout) : RecyclerView.ViewHolder(frame)

class MainActivity : Activity() {

    data class AppItem(
        val label: String,
        val pkg: String,
        val intent: Intent,
        val bmp: Bitmap,
        val glow: Int,
        val cat: Int
    )

    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var counts: SharedPreferences
    private var allApps: List<AppItem> = emptyList()

    // main ui
    private lateinit var pager: ViewPager2
    private lateinit var pagerAdapter: PagerAdapter
    private lateinit var dotsBox: LinearLayout
    private lateinit var clockView: ClockView
    private var pageViews: List<View> = emptyList()
    private val parallax = ArrayList<Pair<View, View>>()
    private lateinit var contentRoot: FrameLayout

    // dashboard
    private lateinit var dashScroll: ScrollView
    private lateinit var dashView: View
    private lateinit var ring: RingView
    private lateinit var batText: TextView
    private lateinit var ramBar: BarView
    private lateinit var ramText: TextView
    private lateinit var stoBar: BarView
    private lateinit var stoText: TextView

    // drawer
    private lateinit var drawer: LinearLayout
    private lateinit var list: RecyclerView
    private lateinit var searchBox: EditText
    private lateinit var chip: TextView
    private lateinit var adapter: AppAdapter
    private var drawerOpen = false
    private var catFilter = -1

    private lateinit var detector: GestureDetector
    private var receiverRegistered = false
    private var torchOn = false
    private var tiltX = 0f
    private var tiltY = 0f
    private val handler = Handler(Looper.getMainLooper())
    private val dashTick = object : Runnable {
        override fun run() {
            updateDash()
            handler.postDelayed(this, 30000)
        }
    }

    private val accents = intArrayOf(
        c(0xFFFF3B30), c(0xFF00E5FF), c(0xFF7C4DFF), c(0xFF2ECC40), c(0xFFFF9500)
    )
    private val accentNames = arrayOf("أحمر", "سماوي", "بنفسجي", "أخضر", "برتقالي")
    private val catNames = arrayOf(
        "🎮 ألعاب", "💬 تواصل", "🎧 وسائط", "💼 إنتاجية وأخبار", "🧭 خرائط وسفر", "🧩 أدوات وأخرى"
    )
    private val accent: Int
        get() = accents[prefs.getInt("accent", 0).coerceIn(0, accents.size - 1)]

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val tx = (-e.values[0] / 5f).coerceIn(-1f, 1f)
            val ty = (e.values[1] / 8f - 0.6f).coerceIn(-1f, 1f)
            tiltX += (tx - tiltX) * 0.12f
            tiltY += (ty - tiltY) * 0.12f
            applyTilt()
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    // ---------- helpers ----------
    private fun c(v: Long): Int = v.toInt()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun glass(radius: Int, fill: Int = c(0x26FFFFFF), stroke: Int = c(0x33FFFFFF)): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radius).toFloat()
        g.setStroke(dp(1), stroke)
        return g
    }

    private fun metal(radius: Int): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(c(0xFF30323A), c(0xFF15161A))
        )
        g.cornerRadius = dp(radius).toFloat()
        g.setStroke(dp(1), c(0x33FFFFFF))
        return g
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hidden(): Set<String> = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
    private val visible: List<AppItem>
        get() = allApps.filter { !hidden().contains(it.pkg) }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        counts = getSharedPreferences("counts", MODE_PRIVATE)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (abs(dy) < abs(dx)) return false
                val onDash = pager.currentItem == 0
                if (!drawerOpen && vy < -800 && dy < -dp(80)) {
                    if (!onDash || !dashScroll.canScrollVertically(1)) {
                        openDrawer(false)
                        return true
                    }
                }
                if (!drawerOpen && vy > 800 && dy > dp(80)) {
                    if (!onDash || !dashScroll.canScrollVertically(-1)) {
                        expandStatusBar()
                        return true
                    }
                }
                if (drawerOpen && vy > 1500 && dy > dp(120) && !list.canScrollVertically(-1)) {
                    closeDrawer()
                    return true
                }
                return false
            }
        })

        setContentView(buildUi())
        BadgeStore.listener = { invalidateTree(contentRoot) }
        loadApps()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, f)
        }
        receiverRegistered = true
    }

    override fun onResume() {
        super.onResume()
        clockView.accent = accent
        handler.post(dashTick)
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc != null && prefs.getInt("tilt", 2) > 0) {
            sm.registerListener(sensorListener, acc, SensorManager.SENSOR_DELAY_GAME)
        }
        invalidateTree(contentRoot)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(dashTick)
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.unregisterListener(sensorListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        BadgeStore.listener = null
        if (receiverRegistered) {
            try {
                unregisterReceiver(pkgReceiver)
            } catch (e: Exception) {
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (drawerOpen) {
            closeDrawer()
        } else if (pager.currentItem != 1 && pageViews.size > 1) {
            pager.setCurrentItem(1, true)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun invalidateTree(v: View) {
        v.invalidate()
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) invalidateTree(v.getChildAt(i))
        }
    }

    private fun applyTilt() {
        val k = prefs.getInt("tilt", 2) * 0.5f
        for (pr in parallax) {
            pr.first.translationX = tiltX * dp(14) * k
            pr.first.translationY = tiltY * dp(10) * k
            pr.second.translationX = -tiltX * dp(7) * k
            pr.second.translationY = -tiltY * dp(5) * k
        }
    }

    // ---------- UI ----------
    private fun buildUi(): View {
        val outer = FrameLayout(this)
        outer.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(c(0x66000000), c(0xCC000000))
        )
        contentRoot = FrameLayout(this)
        contentRoot.fitsSystemWindows = true
        outer.addView(contentRoot, FrameLayout.LayoutParams(M, M))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        pager = ViewPager2(this)
        pagerAdapter = PagerAdapter()
        pager.adapter = pagerAdapter
        pager.offscreenPageLimit = 4
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
            }
        })
        col.addView(pager, lp(M, 0, 1f))

        // bottom bar: search | dots | drawer
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(14), 0, dp(14), 0)

        val searchBtn = Tile3D(this)
        searchBtn.bmp = Gfx.searchBmp(96)
        searchBtn.glow = accent
        searchBtn.setOnClickListener { openDrawer(true) }
        bar.addView(searchBtn, lp(dp(50), dp(50)))

        dotsBox = LinearLayout(this)
        dotsBox.orientation = LinearLayout.HORIZONTAL
        dotsBox.gravity = Gravity.CENTER
        bar.addView(dotsBox, lp(0, W, 1f))

        val gridBtn = Tile3D(this)
        gridBtn.bmp = Gfx.gridBmp(96)
        gridBtn.glow = accent
        gridBtn.setOnClickListener { openDrawer(false) }
        bar.addView(gridBtn, lp(dp(50), dp(50)))
        col.addView(bar, lp(M, dp(54)))

        clockView = ClockView(this)
        clockView.accent = accent
        clockView.setOnClickListener {
            try {
                startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            } catch (e: Exception) {
            }
        }
        clockView.setOnLongClickListener { showSettings(); true }
        col.addView(clockView, lp(M, dp(116)))

        contentRoot.addView(col, FrameLayout.LayoutParams(M, M))

        dashView = buildDashboard()
        buildDrawer()
        return outer
    }

    private fun buildDots() {
        dotsBox.removeAllViews()
        for (i in pageViews.indices) {
            val d = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c(0x55FFFFFF))
            d.background = g
            val l = lp(dp(8), dp(8))
            l.setMargins(dp(4), 0, dp(4), 0)
            dotsBox.addView(d, l)
        }
        updateDots(pager.currentItem)
    }

    private fun updateDots(pos: Int) {
        for (i in 0 until dotsBox.childCount) {
            val g = dotsBox.getChildAt(i).background as? GradientDrawable ?: continue
            g.setColor(if (i == pos) accent else c(0x55FFFFFF))
            dotsBox.getChildAt(i).scaleX = if (i == pos) 1.4f else 1f
            dotsBox.getChildAt(i).scaleY = if (i == pos) 1.4f else 1f
        }
    }

    inner class PagerAdapter : RecyclerView.Adapter<PageVH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val f = FrameLayout(this@MainActivity)
            f.layoutParams = ViewGroup.LayoutParams(M, M)
            return PageVH(f)
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            holder.frame.removeAllViews()
            val v = pageViews[position]
            (v.parent as? ViewGroup)?.removeView(v)
            holder.frame.addView(v, FrameLayout.LayoutParams(M, M))
        }

        override fun getItemCount(): Int = pageViews.size
    }

    private fun rebuildPages() {
        parallax.clear()
        val pages = ArrayList<View>()
        pages.add(dashView)
        pages.add(buildShelfPage(favSlots()))
        for (chunk in visible.chunked(15)) pages.add(buildShelfPage(chunk))
        pages.add(buildCategories())
        val cur = if (pageViews.isEmpty()) 1 else pager.currentItem
        pageViews = pages
        pagerAdapter.notifyDataSetChanged()
        pager.setCurrentItem(cur.coerceIn(0, pages.size - 1), false)
        buildDots()
        applyTilt()
    }

    // ---------- shelf pages ----------
    private fun buildShelfPage(items: List<AppItem?>): View {
        val page = FrameLayout(this)
        val bg = ShelfBg(this)
        bg.setPadding(0, dp(6), 0, dp(6))
        bg.setOnLongClickListener { showSettings(); true }
        page.addView(bg, FrameLayout.LayoutParams(M, M))

        val rowsLayer = LinearLayout(this)
        rowsLayer.orientation = LinearLayout.VERTICAL
        for (r in 0 until 5) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (cc in 0 until 3) {
                row.addView(slotView(items.getOrNull(r * 3 + cc), cc), lp(0, M, 1f))
            }
            rowsLayer.addView(row, lp(M, 0, 1f))
        }
        page.addView(rowsLayer, FrameLayout.LayoutParams(M, M))
        parallax.add(Pair(bg, rowsLayer))
        return page
    }

    private fun slotView(app: AppItem?, col: Int): View {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER
        cell.translationY = if (col == 1) -dp(4).toFloat() else dp(8).toFloat()
        if (app == null) {
            val plus = TextView(this)
            plus.text = "+"
            plus.textSize = 26f
            plus.setTextColor(c(0x33FFFFFF))
            plus.gravity = Gravity.CENTER
            cell.addView(plus, lp(dp(64), dp(64)))
            cell.setOnClickListener { openDrawer(false) }
            return cell
        }
        val tile = Tile3D(this)
        tile.bmp = app.bmp
        tile.glow = app.glow
        tile.pkg = app.pkg
        cell.addView(tile, lp(dp(70), dp(70)))
        val tv = TextView(this)
        tv.text = app.label
        tv.textSize = 10f
        tv.setTextColor(c(0xDDFFFFFF))
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        cell.addView(tv, lp(dp(76), W))
        cell.setOnClickListener { launch(app) }
        cell.setOnLongClickListener { showAppMenu(app); true }
        press(cell)
        return cell
    }

    private fun press(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }
            false
        }
    }

    private fun favPkgs(): List<String> {
        val saved = prefs.getString("fav", null)
        if (saved != null) return saved.split(",").filter { it.isNotEmpty() }
        val d = defaultDock().toMutableList()
        for (a in visible) {
            if (d.size >= 9) break
            if (!d.contains(a.pkg)) d.add(a.pkg)
        }
        return d
    }

    private fun favSlots(): List<AppItem?> {
        val vis = visible
        val items = favPkgs().mapNotNull { p -> vis.firstOrNull { it.pkg == p } }.take(15)
        return List(15) { items.getOrNull(it) }
    }

    private fun toggleFav(pkg: String) {
        val cur = favPkgs().toMutableList()
        if (cur.contains(pkg)) {
            cur.remove(pkg)
        } else {
            if (cur.size >= 15) {
                toast("الصفحة الرئيسية ممتلئة (١٥ تطبيقاً)")
                return
            }
            cur.add(pkg)
        }
        prefs.edit().putString("fav", cur.joinToString(",")).apply()
        rebuildPages()
    }

    private fun defaultDock(): List<String> {
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_VIEW, Uri.parse("sms:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents.mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.distinct()
    }

    // ---------- categories page ----------
    private fun buildCategories(): View {
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(14), dp(16), dp(10))

        val title = TextView(this)
        title.text = "الفئات الذكية"
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        col.addView(title, lp(M, W))

        val sub = TextView(this)
        sub.text = "تطبيقاتك مرتبة تلقائياً حسب نوعها"
        sub.textSize = 12f
        sub.setTextColor(c(0x99FFFFFF))
        col.addView(sub, lp(M, W))

        val vis = visible
        var row = LinearLayout(this)
        var shown = 0
        for (ci in catNames.indices) {
            val inCat = vis.filter { it.cat == ci }
            if (inCat.isEmpty()) continue
            if (shown % 2 == 0) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                val rl = lp(M, W)
                rl.topMargin = dp(10)
                col.addView(row, rl)
            }
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = metal(22)
            card.setPadding(dp(12), dp(12), dp(12), dp(12))
            val nm = TextView(this)
            nm.text = catNames[ci]
            nm.textSize = 15f
            nm.typeface = Typeface.DEFAULT_BOLD
            nm.setTextColor(Color.WHITE)
            card.addView(nm, lp(M, W))
            val ct = TextView(this)
            ct.text = "${inCat.size} تطبيق"
            ct.textSize = 11f
            ct.setTextColor(accent)
            card.addView(ct, lp(M, W))
            val mini = LinearLayout(this)
            mini.orientation = LinearLayout.HORIZONTAL
            for (a in inCat.take(4)) {
                val t = Tile3D(this)
                t.bmp = a.bmp
                t.glow = a.glow
                t.pkg = a.pkg
                mini.addView(t, lp(dp(32), dp(32)))
            }
            val ml = lp(M, W)
            ml.topMargin = dp(8)
            card.addView(mini, ml)
            card.setOnClickListener { catFilter = ci; openDrawer(false) }
            press(card)
            val cl = lp(0, W, 1f)
            cl.setMargins(dp(4), 0, dp(4), 0)
            row.addView(card, cl)
            shown++
        }
        scroll.addView(col, FrameLayout.LayoutParams(M, W))
        return scroll
    }

    // ---------- dashboard ----------
    private fun metalCard(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = metal(22)
        l.setPadding(dp(14), dp(12), dp(14), dp(12))
        return l
    }

    private fun small(text: String, size: Float = 12f, color: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        return t
    }

    private fun buildDashboard(): View {
        dashScroll = ScrollView(this)
        dashScroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(14), dp(16), dp(10))

        val titleRow = LinearLayout(this)
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val title = small("لوحة التحكم", 22f)
        title.typeface = Typeface.DEFAULT_BOLD
        titleRow.addView(title, lp(0, W, 1f))
        val gear = small("⚙", 26f)
        gear.setPadding(dp(10), 0, dp(10), 0)
        gear.setOnClickListener { showSettings() }
        titleRow.addView(gear, lp(W, W))
        col.addView(titleRow, lp(M, W))

        // battery + system
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val batCard = metalCard()
        batCard.gravity = Gravity.CENTER_HORIZONTAL
        ring = RingView(this)
        batCard.addView(ring, lp(dp(92), dp(92)))
        batText = small("", 11f, c(0xBBFFFFFF))
        batText.gravity = Gravity.CENTER
        batCard.addView(batText, lp(M, W))
        val b1 = lp(0, M, 1f)
        b1.rightMargin = dp(4)
        row1.addView(batCard, b1)

        val sysCard = metalCard()
        sysCard.addView(small("🧠 الذاكرة", 12f))
        ramBar = BarView(this)
        val rbl = lp(M, dp(8))
        rbl.topMargin = dp(6)
        sysCard.addView(ramBar, rbl)
        ramText = small("", 11f, c(0xBBFFFFFF))
        sysCard.addView(ramText, lp(M, W))
        val st = small("💾 التخزين", 12f)
        val stl = lp(M, W)
        stl.topMargin = dp(12)
        sysCard.addView(st, stl)
        stoBar = BarView(this)
        sysCard.addView(stoBar, rbl)
        stoText = small("", 11f, c(0xBBFFFFFF))
        sysCard.addView(stoText, lp(M, W))
        val s1 = lp(0, M, 1.35f)
        s1.leftMargin = dp(4)
        row1.addView(sysCard, s1)
        val r1l = lp(M, W)
        r1l.topMargin = dp(12)
        col.addView(row1, r1l)

        // quick toggles
        val tg1 = LinearLayout(this)
        tg1.orientation = LinearLayout.HORIZONTAL
        tg1.addView(toggle("🔦", "المصباح") { toggleTorch() }, tlp())
        tg1.addView(toggle("📶", "الإنترنت") { openPanel(Settings.ACTION_WIFI_SETTINGS) }, tlp())
        tg1.addView(toggle("🔵", "بلوتوث") { openPanel(Settings.ACTION_BLUETOOTH_SETTINGS) }, tlp())
        val t1l = lp(M, W)
        t1l.topMargin = dp(12)
        col.addView(tg1, t1l)
        val tg2 = LinearLayout(this)
        tg2.orientation = LinearLayout.HORIZONTAL
        tg2.addView(toggle("✈️", "الطيران") { openPanel(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }, tlp())
        tg2.addView(toggle("🔊", "الصوت") { openPanel(Settings.ACTION_SOUND_SETTINGS) }, tlp())
        tg2.addView(toggle("🖥", "الشاشة") { openPanel(Settings.ACTION_DISPLAY_SETTINGS) }, tlp())
        val t2l = lp(M, W)
        t2l.topMargin = dp(8)
        col.addView(tg2, t2l)

        // quick note
        val note = metalCard()
        note.addView(small("📝 ملاحظة سريعة", 12f))
        val et = EditText(this)
        et.hint = "اكتب ملاحظتك هنا…"
        et.setHintTextColor(c(0x66FFFFFF))
        et.setTextColor(Color.WHITE)
        et.textSize = 14f
        et.minLines = 3
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.background = null
        et.setText(prefs.getString("note", ""))
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cn: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cn: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString("note", s?.toString() ?: "").apply()
            }
        })
        note.addView(et, lp(M, W))
        val nl = lp(M, W)
        nl.topMargin = dp(12)
        col.addView(note, nl)

        val credit = small("تطوير: خضر أبو صالحه  •  mankhader@gmail.com", 10f, c(0x66FFFFFF))
        credit.gravity = Gravity.CENTER
        credit.setPadding(0, dp(14), 0, dp(4))
        col.addView(credit, lp(M, W))

        dashScroll.addView(col, FrameLayout.LayoutParams(M, W))
        return dashScroll
    }

    private fun tlp(): LinearLayout.LayoutParams {
        val l = lp(0, W, 1f)
        l.setMargins(dp(4), 0, dp(4), 0)
        return l
    }

    private fun toggle(emoji: String, label: String, action: () -> Unit): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.background = metal(20)
        card.setPadding(dp(6), dp(14), dp(6), dp(12))
        val e = small(emoji, 24f)
        e.gravity = Gravity.CENTER
        card.addView(e, lp(M, W))
        val t = small(label, 11f, c(0xDDFFFFFF))
        t.gravity = Gravity.CENTER
        card.addView(t, lp(M, W))
        card.setOnClickListener { action() }
        press(card)
        return card
    }

    private fun openPanel(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            toast("تعذّر فتح الإعدادات")
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("لا يوجد فلاش في هذا الجهاز")
                return
            }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            toast("تعذّر تشغيل المصباح")
        }
    }

    private fun updateDash() {
        if (!::ring.isInitialized) return
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        ring.fraction = pct / 100f
        ring.color = if (pct <= 15 && !charging) c(0xFFFF3B30) else accent
        ring.centerText = "$pct%"
        ring.invalidate()
        batText.text = (if (charging) "⚡ يشحن" else "🔋 البطارية") + "  •  " + (temp / 10) + "°C"

        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val used = mi.totalMem - mi.availMem
            ramBar.fraction = used.toFloat() / mi.totalMem.toFloat()
            ramBar.color = accent
            ramBar.invalidate()
            ramText.text = fmt(used) + " / " + fmt(mi.totalMem)

            val sf = StatFs(Environment.getDataDirectory().path)
            val total = sf.blockCountLong * sf.blockSizeLong
            val free = sf.availableBlocksLong * sf.blockSizeLong
            stoBar.fraction = (total - free).toFloat() / total.toFloat()
            stoBar.color = accent
            stoBar.invalidate()
            stoText.text = fmt(total - free) + " / " + fmt(total)
        } catch (e: Exception) {
        }
    }

    private fun fmt(bytes: Long): String {
        val gb = bytes / 1073741824.0
        return String.format(java.util.Locale.US, "%.1f GB", gb)
    }

    // ---------- drawer ----------
    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.setBackgroundColor(c(0xF20A0C10))
        drawer.visibility = View.GONE
        drawer.setPadding(dp(12), dp(10), dp(12), 0)
        drawer.isClickable = true

        val handle = View(this)
        handle.background = glass(3, c(0x66FFFFFF), c(0x00000000))
        val hl = lp(dp(44), dp(5))
        hl.gravity = Gravity.CENTER_HORIZONTAL
        hl.bottomMargin = dp(12)
        handle.setOnClickListener { closeDrawer() }
        drawer.addView(handle, hl)

        searchBox = EditText(this)
        searchBox.hint = "ابحث عن تطبيق أو في الويب"
        searchBox.setHintTextColor(c(0x88FFFFFF))
        searchBox.setTextColor(Color.WHITE)
        searchBox.textSize = 16f
        searchBox.background = metal(26)
        searchBox.setPadding(dp(20), 0, dp(20), 0)
        searchBox.isSingleLine = true
        searchBox.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cn: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cn: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        searchBox.setOnEditorActionListener { _, _, _ ->
            val first = adapter.first()
            if (first != null) {
                launch(first)
            } else {
                val q = searchBox.text.toString().trim()
                if (q.isNotEmpty()) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                    } catch (e: Exception) {
                    }
                }
            }
            true
        }
        val sl = lp(M, dp(50))
        sl.bottomMargin = dp(8)
        drawer.addView(searchBox, sl)

        chip = small("", 13f, Color.WHITE)
        chip.background = glass(16)
        chip.setPadding(dp(14), dp(6), dp(14), dp(6))
        chip.visibility = View.GONE
        chip.setOnClickListener { catFilter = -1; applyFilter() }
        val cl = lp(W, W)
        cl.bottomMargin = dp(6)
        drawer.addView(chip, cl)

        adapter = AppAdapter()
        list = RecyclerView(this)
        list.layoutManager = GridLayoutManager(this, 4)
        list.adapter = adapter
        list.clipToPadding = false
        list.setPadding(0, dp(4), 0, dp(12))
        list.overScrollMode = View.OVER_SCROLL_NEVER
        drawer.addView(list, lp(M, 0, 1f))

        contentRoot.addView(drawer, FrameLayout.LayoutParams(M, M))
    }

    private fun openDrawer(focus: Boolean) {
        if (drawerOpen) {
            applyFilter()
            return
        }
        drawerOpen = true
        applyFilter()
        drawer.visibility = View.VISIBLE
        drawer.translationY = resources.displayMetrics.heightPixels.toFloat()
        drawer.animate().translationY(0f).setDuration(300)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (focus && drawerOpen) {
                    searchBox.requestFocus()
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showSoftInput(searchBox, 0)
                }
            }.start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        catFilter = -1
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        searchBox.setText("")
        searchBox.clearFocus()
        drawer.animate().translationY(resources.displayMetrics.heightPixels.toFloat())
            .setDuration(250)
            .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
            .start()
    }

    private fun applyFilter() {
        if (!::adapter.isInitialized) return
        val t = searchBox.text.toString().trim().lowercase()
        var res = visible
        if (catFilter >= 0) {
            res = res.filter { it.cat == catFilter }
            chip.text = catNames[catFilter] + "   ✕"
            chip.visibility = View.VISIBLE
        } else {
            chip.visibility = View.GONE
        }
        if (t.isNotEmpty()) res = res.filter { it.label.lowercase().contains(t) }
        adapter.submit(res)
    }

    inner class AppAdapter : RecyclerView.Adapter<VH>() {
        private var items: List<AppItem> = emptyList()

        fun submit(l: List<AppItem>) {
            items = l
            notifyDataSetChanged()
        }

        fun first(): AppItem? = items.firstOrNull()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val cell = LinearLayout(this@MainActivity)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(dp(2), dp(8), dp(2), dp(8))
            cell.layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT
            )
            val tile = Tile3D(this@MainActivity)
            cell.addView(tile, lp(dp(64), dp(64)))
            val tv = TextView(this@MainActivity)
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            val tl = lp(M, W)
            tl.topMargin = dp(4)
            cell.addView(tv, tl)
            press(cell)
            return VH(cell, tile, tv)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val a = items[position]
            holder.tile.bmp = a.bmp
            holder.tile.glow = a.glow
            holder.tile.pkg = a.pkg
            holder.tile.invalidate()
            holder.tv.text = a.label
            holder.cell.setOnClickListener { launch(a) }
            holder.cell.setOnLongClickListener { showAppMenu(a); true }
        }

        override fun getItemCount(): Int = items.size
    }

    // ---------- apps ----------
    @Suppress("DEPRECATION")
    private fun catOf(info: ApplicationInfo): Int {
        if ((info.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return 0
        return when (info.category) {
            ApplicationInfo.CATEGORY_GAME -> 0
            ApplicationInfo.CATEGORY_SOCIAL -> 1
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> 2
            ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS -> 3
            ApplicationInfo.CATEGORY_MAPS -> 4
            else -> 5
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val result = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val launch = Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(pkg, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    val bmp = Gfx.toBitmap(ri.loadIcon(pm), 108)
                    AppItem(
                        ri.loadLabel(pm).toString(), pkg, launch, bmp,
                        Gfx.dominant(bmp), catOf(ri.activityInfo.applicationInfo)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = result
                rebuildPages()
                applyFilter()
                updateDash()
            }
        }.start()
    }

    private fun launch(app: AppItem) {
        try {
            counts.edit().putInt(app.pkg, counts.getInt(app.pkg, 0) + 1).apply()
            startActivity(app.intent)
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            if (drawerOpen) {
                handler.postDelayed({ closeDrawer() }, 400)
            }
        } catch (e: Exception) {
            toast("تعذّر فتح التطبيق")
        }
    }

    // ---------- menus ----------
    private fun showAppMenu(app: AppItem) {
        val inFav = favPkgs().contains(app.pkg)
        val items = arrayOf(
            if (inFav) "إزالة من الصفحة الرئيسية" else "إضافة إلى الصفحة الرئيسية",
            "إخفاء التطبيق",
            "معلومات التطبيق",
            "إلغاء التثبيت"
        )
        AlertDialog.Builder(this).setTitle(app.label).setItems(items) { _, which ->
            try {
                when (which) {
                    0 -> toggleFav(app.pkg)
                    1 -> {
                        val s = HashSet(hidden())
                        s.add(app.pkg)
                        prefs.edit().putStringSet("hidden", s).apply()
                        rebuildPages()
                        applyFilter()
                        toast("تم إخفاء ${app.label} (من الإعدادات يمكنك إظهاره)")
                    }
                    2 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                    )
                    3 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                }
            } catch (e: Exception) {
                toast("تعذّر تنفيذ الأمر")
            }
        }.show()
    }

    private fun showSettings() {
        val items = arrayOf(
            "🎨 لون التمييز",
            "🧊 قوة تأثير 3D (الميلان)",
            "🔔 تفعيل شارات الإشعارات",
            "🙈 التطبيقات المخفية",
            "🖼 تغيير الخلفية",
            "⚙ إعدادات الهاتف",
            "ℹ عن المطور"
        )
        AlertDialog.Builder(this).setTitle("إعدادات اللانشر").setItems(items) { _, w ->
            try {
                when (w) {
                    0 -> AlertDialog.Builder(this).setTitle("لون التمييز")
                        .setItems(accentNames) { _, i ->
                            prefs.edit().putInt("accent", i).apply()
                            recreate()
                        }.show()
                    1 -> AlertDialog.Builder(this).setTitle("قوة تأثير 3D")
                        .setItems(arrayOf("بدون", "خفيف", "قوي")) { _, i ->
                            prefs.edit().putInt("tilt", i).apply()
                            recreate()
                        }.show()
                    2 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    3 -> showHidden()
                    4 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "الخلفية"))
                    5 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                    6 -> showAbout()
                }
            } catch (e: Exception) {
                toast("تعذّر تنفيذ الأمر")
            }
        }.show()
    }

    private fun showHidden() {
        val hs = allApps.filter { hidden().contains(it.pkg) }
        if (hs.isEmpty()) {
            toast("لا توجد تطبيقات مخفية")
            return
        }
        AlertDialog.Builder(this).setTitle("اضغط على التطبيق لإظهاره")
            .setItems(hs.map { it.label }.toTypedArray()) { _, i ->
                val s = HashSet(hidden())
                s.remove(hs[i].pkg)
                prefs.edit().putStringSet("hidden", s).apply()
                rebuildPages()
                applyFilter()
            }.show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("لانشر خضر 3D")
            .setMessage(
                "الإصدار 2.0\n\nتطوير: خضر أبو صالحه\nmankhader@gmail.com\n\n" +
                        "• اسحب يميناً ويساراً بين لوحة التحكم والرئيسية وصفحات التطبيقات والفئات.\n" +
                        "• اسحب للأعلى لدرج التطبيقات، وللأسفل للإشعارات.\n" +
                        "• أمِل الهاتف لترى تأثير العمق ثلاثي الأبعاد.\n" +
                        "• اضغط مطولاً على أي تطبيق للخيارات، وعلى الساعة للإعدادات."
            )
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun expandStatusBar() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
        }
    }
}
