package com.khader.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Shared notification badge counts (filled by NotifService). */
object BadgeStore {
    @Volatile
    var counts: Map<String, Int> = emptyMap()
    var listener: (() -> Unit)? = null

    fun set(m: Map<String, Int>) {
        counts = m
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }
}

object Gfx {
    fun toBitmap(d: Drawable, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return b
    }

    fun dominant(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 12, 12, true)
        var r = 0f
        var g = 0f
        var bl = 0f
        var ws = 0f
        val hsv = FloatArray(3)
        for (x in 0 until 12) {
            for (y in 0 until 12) {
                val p = s.getPixel(x, y)
                if (Color.alpha(p) < 120) continue
                Color.colorToHSV(p, hsv)
                val w = 0.15f + hsv[1] * hsv[2]
                r += Color.red(p) * w
                g += Color.green(p) * w
                bl += Color.blue(p) * w
                ws += w
            }
        }
        if (ws == 0f) return Color.rgb(120, 140, 255)
        val out = Color.rgb((r / ws).toInt(), (g / ws).toInt(), (bl / ws).toInt())
        Color.colorToHSV(out, hsv)
        hsv[1] = (hsv[1] * 1.3f).coerceAtMost(1f)
        hsv[2] = hsv[2].coerceIn(0.75f, 1f)
        return Color.HSVToColor(hsv)
    }

    fun searchBmp(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.color = Color.WHITE
        p.strokeWidth = s * 0.09f
        p.strokeCap = Paint.Cap.ROUND
        c.drawCircle(s * 0.42f, s * 0.42f, s * 0.26f, p)
        c.drawLine(s * 0.62f, s * 0.62f, s * 0.84f, s * 0.84f, p)
        return b
    }

    fun gridBmp(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        val pos = floatArrayOf(0.22f, 0.5f, 0.78f)
        for (x in pos) for (y in pos) c.drawCircle(s * x, s * y, s * 0.075f, p)
        return b
    }
}

/** 3D beveled "keycap" tile with colored glow and notification badge. */
class Tile3D(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
    var glow: Int = Color.CYAN
    var pkg: String = ""

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val r2 = RectF()
    private val dst = RectF()

    init {
        p.isFilterBitmap = true
        txt.color = Color.WHITE
        txt.textAlign = Paint.Align.CENTER
        txt.typeface = Typeface.DEFAULT_BOLD
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w, h)
        val ox = (w - s) / 2f
        val oy = (h - s) / 2f
        val inset = s * 0.08f
        r.set(ox + inset, oy + inset, ox + s - inset, oy + s - inset * 1.4f)
        val rad = s * 0.24f
        val gr = Color.red(glow)
        val gg = Color.green(glow)
        val gb = Color.blue(glow)

        // glow
        p.shader = null
        p.style = Paint.Style.STROKE
        for (i in 4 downTo 1) {
            p.strokeWidth = s * 0.026f * i
            p.color = Color.argb(24, gr, gg, gb)
            canvas.drawRoundRect(r, rad, rad, p)
        }

        // body
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, r.top, 0f, r.bottom,
            0xFF4A4D54.toInt(), 0xFF1A1B1F.toInt(), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r, rad, rad, p)

        // bevel highlight
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.03f
        p.shader = LinearGradient(
            0f, r.top, 0f, r.bottom,
            intArrayOf(0xCCFFFFFF.toInt(), 0x22FFFFFF, 0x66000000),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r, rad, rad, p)

        // recessed plate
        val ip = s * 0.1f
        r2.set(r.left + ip, r.top + ip, r.right - ip, r.bottom - ip)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, r2.top, 0f, r2.bottom,
            0xFF0D0E11.toInt(), 0xFF2A2C32.toInt(), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r2, rad * 0.7f, rad * 0.7f, p)

        // colored rim
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.035f
        p.shader = LinearGradient(
            0f, r2.top, 0f, r2.bottom,
            Color.argb(0, gr, gg, gb), Color.argb(230, gr, gg, gb), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r2, rad * 0.7f, rad * 0.7f, p)

        // icon
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        val b = bmp
        if (b != null) {
            val isz = s * 0.5f
            val cx = r.centerX()
            val cy = r.centerY()
            dst.set(cx - isz / 2f, cy - isz / 2f, cx + isz / 2f, cy + isz / 2f)
            canvas.drawBitmap(b, null, dst, p)
        }

        // badge
        val n = BadgeStore.counts[pkg] ?: 0
        if (n > 0) {
            val br = s * 0.17f
            val bx = r.right - br * 0.2f
            val by = r.top + br * 0.2f
            p.color = 0xFF111111.toInt()
            canvas.drawCircle(bx, by, br + s * 0.02f, p)
            p.color = 0xFF2ECC40.toInt()
            canvas.drawCircle(bx, by, br, p)
            txt.textSize = br * 1.25f
            val label = if (n > 99) "99+" else n.toString()
            canvas.drawText(label, bx, by - (txt.descent() + txt.ascent()) / 2f, txt)
        }
    }
}

/** Dark metal chevron shelves, like layered armor plates. */
class ShelfBg(ctx: Context) : View(ctx) {
    var rows = 5
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val edge = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bh = h / rows
        for (i in 0 until rows) {
            val y = i * bh
            val peak = bh * 0.22f
            val th = bh * 0.86f
            path.reset()
            path.moveTo(0f, y + peak)
            path.lineTo(w / 2f, y)
            path.lineTo(w, y + peak)
            path.lineTo(w, y + peak + th)
            path.lineTo(w / 2f, y + th)
            path.lineTo(0f, y + peak + th)
            path.close()
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(
                0f, y, 0f, y + bh,
                0xEE34363B.toInt(), 0xEE131417.toInt(), Shader.TileMode.CLAMP
            )
            canvas.drawPath(path, p)

            edge.reset()
            edge.moveTo(0f, y + peak)
            edge.lineTo(w / 2f, y)
            edge.lineTo(w, y + peak)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.5f
            p.color = 0x77FFFFFF
            canvas.drawPath(edge, p)

            edge.reset()
            edge.moveTo(0f, y + peak + th)
            edge.lineTo(w / 2f, y + th)
            edge.lineTo(w, y + peak + th)
            p.strokeWidth = 3f
            p.color = 0x99000000.toInt()
            canvas.drawPath(edge, p)
        }
    }
}

/** 3D digital clock with day/date and a mirrored reflection. */
class ClockView(ctx: Context) : View(ctx) {
    var accent: Int = 0xFFFF3B30.toInt()

    private val big = Paint(Paint.ANTI_ALIAS_FLAG)
    private val small = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mask = Paint()
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            handler.postDelayed(this, 1000)
        }
    }

    init {
        big.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
        small.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
        label.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(tick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(tick)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = Date()
        val hm = SimpleDateFormat("HH:mm", Locale.US).format(now)
        val sec = SimpleDateFormat(":ss", Locale.US).format(now)
        val day = SimpleDateFormat("EEEE", Locale.getDefault()).format(now)
        val date = SimpleDateFormat("d MMM", Locale.getDefault()).format(now)

        val pad = w * 0.06f
        label.textSize = h * 0.15f
        label.color = accent
        label.textAlign = Paint.Align.LEFT
        canvas.drawText(day, pad, h * 0.2f, label)
        label.color = Color.WHITE
        label.textAlign = Paint.Align.RIGHT
        canvas.drawText(date, w - pad, h * 0.2f, label)

        big.textSize = h * 0.46f
        small.textSize = h * 0.26f
        val wHm = big.measureText(hm)
        val wSec = small.measureText(sec)
        val startX = (w - (wHm + wSec)) / 2f
        val baseY = h * 0.62f

        big.color = Color.WHITE
        big.setShadowLayer(h * 0.08f, 0f, 0f, accent)
        small.color = 0xFF8A8D93.toInt()
        canvas.drawText(hm, startX, baseY, big)
        big.clearShadowLayer()
        canvas.drawText(sec, startX + wHm, baseY, small)

        // reflection
        val sc = canvas.saveLayer(0f, baseY, w, h, null)
        canvas.save()
        canvas.scale(1f, -1f, 0f, baseY)
        big.color = 0x88FFFFFF.toInt()
        small.color = 0x558A8D93
        canvas.drawText(hm, startX, baseY, big)
        canvas.drawText(sec, startX + wHm, baseY, small)
        canvas.restore()
        mask.shader = LinearGradient(
            0f, baseY, 0f, h, 0x88FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, baseY, w, h, mask)
        canvas.restoreToCount(sc)
    }
}

class RingView(ctx: Context) : View(ctx) {
    var fraction = 0f
    var color = Color.CYAN
    var centerText = ""

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val sw = s * 0.11f
        rect.set(sw, sw, s - sw, s - sw)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0x33FFFFFF
        canvas.drawArc(rect, 0f, 360f, false, p)
        p.color = color
        canvas.drawArc(rect, -90f, 360f * fraction.coerceIn(0f, 1f), false, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = s * 0.24f
        p.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(centerText, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
    }
}

class BarView(ctx: Context) : View(ctx) {
    var fraction = 0f
    var color = Color.CYAN

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0x33FFFFFF
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, p)
        p.color = color
        rect.set(0f, 0f, maxOf(h, w * fraction.coerceIn(0f, 1f)), h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, p)
    }
}
