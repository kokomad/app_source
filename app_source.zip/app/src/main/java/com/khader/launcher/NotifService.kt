package com.khader.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Counts active notifications per app to draw badges on the 3D tiles. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        update()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        update()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        update()
    }

    private fun update() {
        try {
            val m = HashMap<String, Int>()
            val list = activeNotifications
            if (list != null) {
                for (n in list) {
                    m[n.packageName] = (m[n.packageName] ?: 0) + 1
                }
            }
            BadgeStore.set(m)
        } catch (e: Exception) {
        }
    }
}
